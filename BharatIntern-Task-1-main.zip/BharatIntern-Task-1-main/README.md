Content Management Tool :-                                          
This is task 1 of my Internship in Bharat intern.                                    
I use HTML, CSS, and JavaScript For Front-end Development and Visual Studio Code as my IDE.
